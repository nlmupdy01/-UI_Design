$(function() {

  rome(input, { time: false });
   rome(input2, { time: false });
   rome(input3, { time: false });
   rome(input4, { time: false });

});